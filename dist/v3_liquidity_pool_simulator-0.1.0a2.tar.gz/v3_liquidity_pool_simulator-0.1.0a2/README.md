# V3 Liquidity Pool Simulator

A simple Python package to simulate earnings in a Uniswap V3 liquidity pool for USDC and USDT tokens.

## Installation

Run the following command to install:

```bash
pip install v3_liquidity_pool_simulator
